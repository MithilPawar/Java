package myPack;

public class Student {
	private int rollNo;
	private String name;
	private double percentage;
	private String address;
	
	public Student() {
		super();
		
	}

	public Student(int rollNo, String name, double percentage, String address) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.percentage = percentage;
		this.address = address;
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", percentage=" + percentage + ", address=" + address
				+ "]";
	}
	
}
