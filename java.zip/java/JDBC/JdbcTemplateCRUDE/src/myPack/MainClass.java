package myPack;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext appctx = new ClassPathXmlApplicationContext("config.xml");
		StudentDAO s1 = (StudentDAO) appctx.getBean("studbean");
		Student s = new Student(60, "mithil", 98, "Ratnagiri");
		
//		int rowAffect = s1.saveStudent(s);
//		if(rowAffect != 0) {
//			System.out.println("Data saved successfully.......");
//		}
//		else {
//			System.out.println("Error......");
//		}
//		
//		System.out.println("----Student Details----");
//		s1.getDetails();
		
//		s1.getSingleRecord(60);
		
		//s1.deleteStudent(60);
		
//		Student s2 = new Student(60, "mithil", 95, "Rajapur");
//		s1.updateStudent(s2);
		
		System.out.println(s1.getSingleRecordUsingRowMapper(60));
	
	}

}
