package myPack;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class StudentDAO {
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int saveStudent(Student s1) {
		String sqlStr = "INSERT INTO student (rollNo, name, percentage, address) VALUES (" + s1.getRollNo() + ", '" + s1.getName() + "', " + s1.getPercentage() + ", '" + s1.getAddress() + "')";
		return jdbcTemplate.update(sqlStr);
	}
	
	public void getDetails() {
		String sqlStr = "SELECT * FROM student";
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sqlStr);
		for(Map<String, Object> row : results) {
			for(Map.Entry<String, Object> entry : row.entrySet()) {
				String column = entry.getKey();
				Object value = entry.getValue();
				System.out.println(column + ": " + value);
			}
			System.out.println("-----------");
		}
	}
	
	public void getSingleRecord(int rollNo) {
		String sqlStr = "SELECT * FROM student WHERE rollNo = ?";
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sqlStr, rollNo);
		
		if(!results.isEmpty()) {
			System.out.println("Student with roll number " + rollNo + " found");
			for(Map<String, Object> row : results) {
				for(Map.Entry<String, Object> entry : row.entrySet()) {
					String column = entry.getKey();
					Object value = entry.getValue();
					System.out.println(column + ": " + value);
				}
				System.out.println("-----------");
			}
		}
		else {
			System.out.println("Student with roll number " + rollNo + " not found");
		}
	}
	
	public Student getSingleRecordUsingRowMapper(int rollNo) {
	    String sqlstr = "SELECT * FROM student WHERE rollNo = ?";
	    return jdbcTemplate.queryForObject(sqlstr, BeanPropertyRowMapper.newInstance(Student.class), rollNo);
	}
	
	public void deleteStudent(int rollNo) {
		String sqlStr = "DELETE FROM student WHERE rollNo = ?";
	    
	    int rowsAffected = jdbcTemplate.update(sqlStr, rollNo);

	    if (rowsAffected > 0) {
	        System.out.println("Student with roll number " + rollNo + " deleted successfully");
	    } else {
	        System.out.println("Student with roll number " + rollNo + " not found");
	    }
	}
	
	public void updateStudent(Student student) {
	    String sqlStr = "UPDATE student SET name = ?, percentage = ?, address = ? WHERE rollNo = ?";

	    int rowsAffected = jdbcTemplate.update(
	            sqlStr,
	            student.getName(),
	            student.getPercentage(),
	            student.getAddress(),
	            student.getRollNo()
	    );

	    if (rowsAffected > 0) {
	        System.out.println("Student with roll number " + student.getRollNo() + " updated successfully");
	    } else {
	        System.out.println("Student with roll number " + student.getRollNo() + " not found");
	    }
	}

}
