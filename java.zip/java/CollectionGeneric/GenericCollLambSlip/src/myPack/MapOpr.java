package myPack;

import java.util.HashMap;
import java.util.Map;

public class MapOpr {

	public static void main(String[] args) {
		Map<Integer, String> mp = new HashMap<Integer, String>();
		Map<Integer, String> mp2 = new HashMap<Integer, String>();
		
		mp.put(1, "one");
		mp.put(2, "two");
		mp.put(3, "three");
		
		mp.remove(1);
		
		mp.containsKey(1);
		
		mp2.putAll(mp);
		
		System.out.println("Key and Value of Map: ");
		
		for(Map.Entry<Integer, String> ent : mp.entrySet()) {
			System.out.println("Key: " + ent.getKey() + "Value: "+ ent.getValue());
		}
		
	}

}
