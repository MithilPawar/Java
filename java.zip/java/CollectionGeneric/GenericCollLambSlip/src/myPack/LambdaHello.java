package myPack;

@FunctionalInterface
interface PrintMsg{
	public void Hello();
}

public class LambdaHello {

	public static void main(String[] args) {
		PrintMsg pm = () ->{
			System.out.println("Hello World");
		};
		
		pm.Hello();
	}

}
