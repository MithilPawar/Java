package myPack;

import java.util.HashSet;
import java.util.Set;

public class SrtOpr {

	public static void main(String[] args) {
		Set<String> st = new HashSet<String>();
		Set<String> st2 = new HashSet<String>();
		
		st.add("Mithil");
		st.add("Bhavesh");
		st.add("Omkar");
		System.out.println(st);
		st2.addAll(st);
		System.out.println(st2);
		st.remove("Mithil");
		System.out.println(st);
		System.out.println(st.contains("Mithil"));
	}

}
