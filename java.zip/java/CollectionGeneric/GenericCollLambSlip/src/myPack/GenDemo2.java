package myPack;

//Define a generic class called GenT, and a second class called GenDemo, which uses
//GenT. The GenT class should have parameter T that will be replaced by a data type 
//whenever the object of type GenT is created. write a java program to implement simple
//use of generic class and demonstrate by using various primitive data type in place of T.

class GenT<T>{
	T t;

	public GenT(T t) {
		super();
		this.t = t;
	}

	public T getT() {
		return t;
	}

	public void setT(T t) {
		this.t = t;
	}
	
	public void getType() {
		System.out.println("Type of T is : " + t.getClass().getName());
	}
}
public class GenDemo2 {

	public static void main(String[] args) {
		GenT<String> s = new GenT<>("Mithil");
		GenT<Integer> i = new GenT<>(10);
		GenT<Double> d = new GenT<>(25.56);
		GenT<Boolean> b = new GenT<>(false);
		
		s.getType();
		i.getType();
		d.getType();
		b.getType();
	}

}
