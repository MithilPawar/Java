package myPack;

//Write a program to demonstrate generic method
public class GenMethod {

	public static void main(String[] args) {

	}

}
