package myPack;

public class WildCard {

	public static void main(String[] args) {
		
	}

}
