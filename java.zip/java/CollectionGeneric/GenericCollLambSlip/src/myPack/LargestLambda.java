package myPack;

@FunctionalInterface
interface Largest{
	public int LargeOf3(int n1, int n2, int n3);
}

public class LargestLambda {

	public static void main(String[] args) {
		
		Largest l = (n1, n2, n3) ->{
			if(n1 > n2 && n1 > n3) {
				return n1;
			}
			else if(n2 >= n1 && n2 >= n3) {
				return n2;
			}
			else {
				return n3;
			}
		};
		
		System.out.println("Largest Number is: " + l.LargeOf3(5, 23, 3));
	}

}
