package myPack;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class ListItr {

	public static void main(String[] args) {
		List<String> s = new ArrayList<String>();
		
		s.add("1");
		s.add("2");
		s.add("3");
		
		ListIterator<String> ltr = s.listIterator();
		System.out.println("Forward: ");
		while(ltr.hasNext()) {
			String str = ltr.next();
			System.out.println(str);
		}
		
		System.out.println("\nBackward:");
		while(ltr.hasPrevious()) {
			String str = ltr.previous();
			System.out.println(str);
		}

	}

}
