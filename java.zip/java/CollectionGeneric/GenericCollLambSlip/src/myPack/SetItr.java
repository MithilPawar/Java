package myPack;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class SetItr {

    public static void main(String[] args) {
        Set<Integer> st = new HashSet<Integer>();
        st.add(10);
        st.add(20);
        st.add(30);
        st.add(40);

        // Iterating over Set<Integer>
        Iterator<Integer> itr = st.iterator();
        while (itr.hasNext()) {
            Integer i = itr.next();
            System.out.println(i);
        }

        // Adding elements to Set<String>
        Set<String> st1 = new HashSet<String>();
        st1.add("John");
        st1.add("Alice");
        st1.add("Bob");

        // You can use Iterator for Set<String> as well
        Iterator<String> stringIterator = st1.iterator();
        while (stringIterator.hasNext()) {
            String s = stringIterator.next();
            System.out.println(s);
        }
    }
}
