package myPack;

import java.util.ArrayList;
import java.util.List;

public class ListFor {

	public static void main(String[] args) {
		List<String> al = new ArrayList<String>();
		
		al.add("Mithil");
		al.add("omkar");
		al.add("Bhavesh");
		
		for (String str : al) {
			System.out.println(str);
		}

	}

}
