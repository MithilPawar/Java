package myPack;

//Define a generic class GenAB,  and a second class called GenDemo which uses 
//GenAB. The GenAB class should have at least two parameters namely A and B that 
//will be replaced by different data type whenever the object of type GenAB is 
//created. write a java program to implement simple use of generic class and 
//demonstrate by using various primitive data type in place of generic types

class GenAB<A, B>{
	private A num1;
	private B num2;
	
	public GenAB(A num1, B num2) {
		this.num1 = num1;
		this.num2 = num2;
	}
	
	public A getValueA() {
		return num1;
	}
	
	public B getValueB() {
		return num2;
	}
}

public class GenDemo {

	public static void main(String[] args) {
		GenAB<Integer, Double> g1 = new GenAB<>(11, 15.55);
		System.out.println("Values of A: " + g1.getValueA() + " Values of B: " + g1.getValueB());
		
		GenAB<String, Boolean> g2 = new GenAB<>("11", true);
		System.out.println("Values of A: " + g2.getValueA() + " Values of B: " + g2.getValueB());
	}

}
