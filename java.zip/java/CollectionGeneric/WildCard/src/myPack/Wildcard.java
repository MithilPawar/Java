package myPack;


class TwoD{
	int x,y;
	TwoD(int a,int b){
		x=a;
		y=b;
	}
}

class ThreeD extends TwoD{
	int z;
	ThreeD(int a,int b,int c){
		super(a,b);
		z=c;
	}
}

class FourD extends ThreeD{
	int s;
	FourD(int a,int b,int c,int d){
		super(a, b, c);
		s=d;
	}
}

class Coords<T extends TwoD>{
	T coords;
	Coords(T o){
		coords=o;
	}
}

public class Wildcard {
	static void showXY(Coords<?> c) {
		System.out.println(c.coords.x+"-"+c.coords.y);
	}
	
	static void showXYZ(Coords<? extends ThreeD> c) {
		System.out.println(c.coords.x+"-"+c.coords.y+"-"+c.coords.z);
	}
	
	static void showXZYS(Coords<? extends FourD> c) {
		System.out.println(c.coords.s);
	}
	
	static void showXYL(Coords<? super TwoD> c) {
        System.out.println("X: " + ((TwoD) c.coords).x + ", Y: " + ((TwoD) c.coords).y);
    }
	
	public static void main(String ar[]) {
		TwoD td=new TwoD(10, 12);
		Coords <TwoD> ct=new Coords<TwoD>(td);
		showXY(ct);
		
		ThreeD thd=new ThreeD(23, 45, 67);
		Coords<ThreeD> cxt=new Coords<ThreeD>(thd);
		showXYZ(cxt);
		
		showXYL(ct);
	}
}



