package myPack;

//Write a Java program using Lambda Expression to concatenate two strings.

@FunctionalInterface
interface ConcateString{
	public void conc(String s1, String s2);
}
public class Q13 {

	public static void main(String[] args) {
		ConcateString c = (s1, s2) ->{
			System.out.println(s1 + s2);
		};
		
		c.conc("mithil", "pawar");
	}

}
