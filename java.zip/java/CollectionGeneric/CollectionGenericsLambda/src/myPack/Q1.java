package myPack;

//Develop a Java Program to demonstrate a Generic Class with generic method to 
//swap two different elements in an array.

public class Q1{
	
	public static <T> void swap(T[] arr, int i1, int i2) {
		if(i1 < 0 || i1 >= arr.length || i2 < 0 || i2 >= arr.length) {
			System.out.println("Invalid indexes");
		}
		else {
			T temp = arr[i1];
			arr[i1] = arr[i2];
			arr[i2] = temp;
			
		}
	}
	
	public static <T> void PrintArray(T[] arr) {
		for(T element : arr) {
			System.out.print(element + " ");
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		Integer[] arr = {1, 5, 2, 6, 8};
		PrintArray(arr);
		swap(arr, 1, 4);
		PrintArray(arr);
	}
}