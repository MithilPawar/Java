package myPack;

import java.util.ArrayList;
import java.util.List;

//You are working as a software developer for a company that develops mobile apps. 
//The app allows users to create and manage lists of items. You have been tasked 
//with improving the performance of the app&#39;s list management features. You decide to use the following
//techniques:
//a. Use a generic list to store, delete, retrieve, and find the items in the list.
//b. Use a lambda expression to filter and sort the list of items.

public class Q4<T> {

}
