package myPack;

//Create a generic class called &quot;DataManager&quot; that can store and manage 
//a collection of objects of any type. The &quot;DataManager&quot; class should 
//provide methods to add objects tothe collection, remove objects from the 
//collection, and retrieve objects from the collection. Implement a method in the 
//&quot;DataManager&quot; class that takes a lambda  expression as a
//parameter and applies it to each object in the collection. Also, implement a 
//method in the &quot;DataManager&quot; class that uses a lambda expression to 
//filter the collection based on a given condition. The method should return a 
//new collection containing only the 
//objects that satisfy the condition.

public class Q16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
