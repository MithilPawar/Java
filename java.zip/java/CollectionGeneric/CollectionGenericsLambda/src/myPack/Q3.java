package myPack;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

//Create a Java program that demonstrates the following operations:
//a. Create an ArrayList and add elements to it.
//b. Access elements from the ArrayList using both index-based and iterator-based
//approaches.
//c. Modify elements in the ArrayList.
//d. Remove elements from the ArrayList.

public class Q3 {

	public static void main(String[] args) {
		
		ArrayList<String> al = new ArrayList<String>();
		al.add("Harrier");
		al.add("Verna");
		al.add("Punch");
		al.add("Slavia");
		
		ListIterator<String> itr = al.listIterator();
		System.out.println("Forward");
		while(itr.hasNext()) {
			String arr = itr.next();
			System.out.println(arr);
		}
		System.out.println("\nBackward");
		while(itr.hasPrevious()) {
			String str = itr.previous();
			System.out.println(str);
		}
		
		System.out.println("\nAfter Modification: ");
		al.set(2, "Fortuner");
		System.out.println(al);
		
		System.out.println("\nAfter removing element: ");
		al.remove(1);
		System.out.println(al);
	}

}
