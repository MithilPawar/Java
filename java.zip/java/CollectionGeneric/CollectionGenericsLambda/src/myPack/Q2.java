package myPack;

//Write a Java program using Lambda Expression to calculate the following:
//a. Convert Fahrenheit to Celsius
//b. Convert Kilometers to Miles.

//@FunctionalInterface
//interface FahrToCel{
//	public void calc(double temp);
//}

@FunctionalInterface
interface KmToMile{
	public void calc(double km);
}

public class Q2 {

	public static void main(String[] args) {
		
//		FahrToCel t = (temp) ->{
//			double conv = (temp - 32) * 5/9 ;
//			System.out.println("Fahrenheit to Celsius is: "+ conv);
//		};
//		
//		double temp = 150;
//		t.calc(temp);
		
		KmToMile k = (km) ->{
			double conv = km * 0.62137119;
			System.out.println("Kilometers to mile is: " + conv);
		};
		
		k.calc(100);
	}
}
