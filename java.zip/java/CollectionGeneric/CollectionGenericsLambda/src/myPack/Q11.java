package myPack;

//Write a Java program using Lambda Expression with multiple parameters to add two
//numbers.

@FunctionalInterface
interface addition{
	public int add(int a, int b);
}
public class Q11 {

	public static void main(String[] args) {
		addition ad = (a, b) ->{
			return a + b;
		};
		
		int a = 10;
		int b = 2;
		
		System.out.println("Addition is :" + ad.add(a, b));

	}

}
