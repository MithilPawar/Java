package myPack;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.ListIterator;
import java.util.Set;


//Write a Java program to create a Set containing list of items of type String and 
//print the items in the list using Iterator interface. Also print the list in 
//reverse/ backword direction.

public class Q7 {

	public static void main(String[] args) {
		
	}
}
