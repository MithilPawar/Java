package myPack;


//Develop a Java Program to demonstrate Wildcards in Java Generics.

public class Q5 {

	public static void main(String[] args) {

	}

}
