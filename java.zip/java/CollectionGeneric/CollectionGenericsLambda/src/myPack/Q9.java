package myPack;

import java.util.HashMap;
import java.util.Map;

//Write a Java program using Map interface containing list of items having keys 
//and associated values and perform the following operations:
//a. Add items to the map.
//b. Remove items from the map.
//c. Search for a specific key from the map.
//d. Get value of the specified key
//e. Insert map elements of one map into another map.
//f. Print all keys and values of the map.

public class Q9 {

	public static void main(String[] args) {
		Map<Integer, String> mp = new HashMap<Integer, String>();
		Map<Integer, String> mp2 = new HashMap<Integer, String>();
		mp.put(1, "one");
		mp.put(2, "two");
		mp.put(3, "three");
		mp.put(4, "four");
		mp.put(5, "five");
		
		System.out.println(mp);
		
		mp.remove(2);
		System.out.println(mp);
		
		System.out.println(mp.containsKey(2));
		
		mp2.putAll(mp);
		System.out.println(mp2);
		
//		Printing keys and values using entry set
		System.out.println("Keys and values of Map are: ");
		for(Map.Entry<Integer, String> ent : mp.entrySet()) {
			System.out.println("Key = " + ent.getKey() + "Value= " + ent.getValue());
		}
	}

}
