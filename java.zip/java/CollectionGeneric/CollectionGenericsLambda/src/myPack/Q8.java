package myPack;

import java.util.HashSet;
import java.util.Set;

//Write a Java program using Set interface containing list of items and 
//perform the following operations:
//a. Add items to the set.
//b. Insert items of one set into other set.
//c. Remove items from the set.
//d. Search for the specified item in the set.

public class Q8 {

	public static void main(String[] args) {
		Set<String> st1 = new HashSet<String>();
		Set<String> st2 = new HashSet<String>();
		
		st1.add("realme");
		st1.add("redmi");
		st1.add("apple");
		st1.add("oneplus");
		
		st2.addAll(st1);
		
		System.out.println(st2);
		
		st1.remove("apple");
		System.out.println(st1);
		
		System.out.println(st2.contains("realme"));
		
	}

}
