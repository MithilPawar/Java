package myPack;

public class Msg {
	String ms;

	public Msg() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getMs() {
		return ms;
	}

	public void setMs(String ms) {
		this.ms = ms;
	}

	@Override
	public String toString() {
		return "Msg [ms=" + ms + "]";
	}
	
}
