package myPack;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AOPClass {
	
	@Pointcut("execution(* myPack.Student.display(..))")
	public void pointcutMethod() {
		
	}
	
//	Matches any class in package myPack
	@Pointcut("within(myPack..*)")
    public void withinPackage() {
        
    }
}
