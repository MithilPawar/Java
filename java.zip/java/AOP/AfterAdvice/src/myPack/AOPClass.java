package myPack;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AOPClass {
	@Pointcut("execution(* myPack.Student.Display())")
	public void pointcutMethod() {
		
	}
	
	@After("pointcutMethod()")
	public void afterDisplay() {
		System.out.println("Inside the after advice");
	}
}
