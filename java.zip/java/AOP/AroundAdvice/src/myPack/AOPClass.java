package myPack;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AOPClass {
    @Pointcut("execution(* myPack.Student.display(..))")
    public void pointcutMethod() {

    }

    @Around("pointcutMethod()")
    public Object aroundAdvice(ProceedingJoinPoint jp) throws Throwable {
        System.out.println("Before method execution - Around advice");

        Object result = jp.proceed();

        System.out.println("After method execution - Around advice");

        return result;
    }
}
