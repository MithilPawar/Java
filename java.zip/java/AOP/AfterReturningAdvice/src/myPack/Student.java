package myPack;

public class Student {
	private int rollNo;
	private String name;
	private int mrk1;
	private int mrk2;
	private int mrk3;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMrk1() {
		return mrk1;
	}
	public void setMrk1(int mrk1) {
		this.mrk1 = mrk1;
	}
	public int getMrk2() {
		return mrk2;
	}
	public void setMrk2(int mrk2) {
		this.mrk2 = mrk2;
	}
	public int getMrk3() {
		return mrk3;
	}
	public void setMrk3(int mrk3) {
		this.mrk3 = mrk3;
	}
	public void CalcPercentage() {
		double per = ((mrk1 + mrk2 + mrk3) / 300 );
		System.out.println("Percentage is: " + per);
	}
}
