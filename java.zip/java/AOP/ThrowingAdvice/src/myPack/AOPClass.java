package myPack;

import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AOPClass {
	
	@Pointcut("execution(* myPack.Student.setPercentage(..))")
	public void pointcutMethod() {
		
	}
	
	@AfterThrowing(pointcut = "pointcutMethod()", throwing = "exc")
	public void handleException(Exception exc) {
		System.out.println("Exception occured: " + exc.getMessage());
	}
}
