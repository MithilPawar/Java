package myPack;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AOPClass {
	@Pointcut("execution(* myPack.Student.Display())")
	public void pointcutMethod() {
		
	}
	
	@Before("pointcutMethod()")
	public void BeforeAdvice() {
		System.out.println("Inside the before advice");
	}
}
