package com.famt.ac.in.SprintBootHelloWorld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintBootHelloWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
